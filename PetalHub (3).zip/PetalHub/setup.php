<?php
require_once __DIR__ . '/config.php';
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

if (!defined('PH_SETUP_TOKEN') || !is_string(PH_SETUP_TOKEN) || strlen(PH_SETUP_TOKEN) < 32){
  http_response_code(404);
  exit('One-time setup is disabled.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST'){
  $token = isset($_POST['token']) && is_string($_POST['token']) ? $_POST['token'] : '';
  if (!hash_equals(PH_SETUP_TOKEN, $token)){
    http_response_code(403);
    exit('Invalid setup token.');
  }
  define('PETALHUB_SETUP_MODE', true);
  require_once __DIR__ . '/api.php';
  exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET'){
  header('Allow: GET, POST');
  http_response_code(405);
  exit('Method not allowed.');
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>PetalHub one-time database setup</title>
</head>
<body>
<main>
  <h1>PetalHub one-time database setup</h1>
  <p>Run this only after importing <code>schema.sql</code> and setting up <code>config.php</code>. This applies compatible migrations and preserves existing records.</p>
  <form method="post">
    <label for="token">One-time setup token</label>
    <input id="token" name="token" type="password" minlength="32" required autocomplete="off">
    <button type="submit">Run database setup</button>
  </form>
</main>
</body>
</html>
